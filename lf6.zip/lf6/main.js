document.addEventListener("DOMContentLoaded", function(){

  startWebSocket();

  resize();
  window.addEventListener("resize", resize);
  document.getElementById("input_text").addEventListener("input", resize);
  input.addEventListener("keyup", function(event){ if(event.keyCode === 13){ event.preventDefault(); sendMessage(); }});

  changeName();

  pushMessage("Hallo, mein Name ist " + chatbotName +", wie kann ich ihnen heute behilflich sein?")

});
