//-----------------------------------------------------------------------------------------------------------------
// Passt die größe des chats an

function resize() {

  var chat     = document.getElementById("chat");
  var header   = document.getElementById("header");
  var messages = document.getElementById("messages");
  var input    = document.getElementById("input");

  var height = chat.offsetHeight - (header.offsetHeight + input.offsetHeight);

  messages.style.height = height + "px";

}



//-----------------------------------------------------------------------------------------------------------------
// Scrolle zum ende des Chats

function scrollDown() {

  var messages = document.getElementById("messages");
  messages.scrollTo({ top: messages.scrollHeight, behavior: 'smooth' });

}



//-----------------------------------------------------------------------------------------------------------------
// Scrolle zum ende des Chats

function changeName() {

  var header = document.getElementById("header_text");
  header.innerHTML = "Chat mit " + chatbotName;

}
