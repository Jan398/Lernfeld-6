function optionClick(option) {

  document.getElementById("input_options").innerHTML = "";
  pushMessage(option, true);

}

function pushOptions(option) {

  var input_option = document.createElement("div");
  input_option.setAttribute("class", "input_option");
  input_option.setAttribute("onclick", "optionClick(this.innerHTML);");
  input_option.innerHTML = option;

  document.getElementById("input_options").appendChild(input_option);

}
