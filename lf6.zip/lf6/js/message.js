//-----------------------------------------------------------------------------------------------------------------
// Globale scheiße unso

chatbotName = "Rüdiger";
myName = "Ich";



//-----------------------------------------------------------------------------------------------------------------
// Prüft ob die eingabe leer ist

function isEmpty(msg) {

  var result = true;
  if(msg != ""){ result = false; }
  return result;

}



//-----------------------------------------------------------------------------------------------------------------
// Entfernt überflüssige Enters

function removeLineBreak(msg) {

  msg = msg.split("<br>")

  var lastBreak = 0;
  for (var i = 0; i < msg.length; i++) { if(msg[i] != ""){ lastBreak = i; } }

  var tempBreak = "";
  for (var i = 0; i < lastBreak+1; i++) {
    tempBreak += msg[i];
    if( i < lastBreak ){ tempBreak += "<br>"; }
  }
  msg = tempBreak;

  return msg;

}



//-----------------------------------------------------------------------------------------------------------------
// Zeigt eine neue nachricht an

function pushMessage(msg, myself=false) {

  var messages = document.getElementById("messages");

  var message          = document.createElement("div");
  var message_triangle = document.createElement("div");
  var message_bubble   = document.createElement("div");
  var message_content  = document.createElement("div");
  var message_name     = document.createElement("div");
  var message_text     = document.createElement("div");
  var message_time     = document.createElement("div");
  var message_spacer   = document.createElement("div");

  if(myself){
    message.setAttribute("class", "message_me");
    message_triangle.setAttribute("class", "message_triangle_me");
    message_name.innerHTML = myName;
  }else{
    message.setAttribute("class", "message");
    message_triangle.setAttribute("class", "message_triangle");
    message_name.innerHTML = chatbotName;
  }

  message_bubble.setAttribute( "class", "message_bubble" );
  message_content.setAttribute("class", "message_content");
  message_name.setAttribute(   "class", "message_name"   );
  message_text.setAttribute(   "class", "message_text"   );
  message_time.setAttribute(   "class", "message_time"   );
  message_spacer.setAttribute( "class", "message_spacer" );

  var date = new Date();
  var m = date.getMinutes();
  var h = date.getHours();
  if(m < 10){ m = "0" + m; } // damit die minuten auch eine 0 vor haben
  if(h < 10){ h = "0" + h; } // damit die stunden auch eine 0 vor haben
  var time = h + ":" + m;

  message_text.innerHTML = msg;
  message_time.innerHTML = time;

  message.appendChild(message_triangle);
  message.appendChild(message_bubble);
  message_bubble.appendChild(message_content);
  message_content.appendChild(message_name);
  message_content.appendChild(message_text);
  message_content.appendChild(message_time);
  message.appendChild(message_spacer);

  messages.appendChild(message);

  scrollDown();

}



//-----------------------------------------------------------------------------------------------------------------
// Sendet eine nachricht an den websocket + checkt dinge + stellt sie dar

function sendMessage() {

  var input = document.getElementById("input_text");
  var message = input.innerHTML;
  message = removeLineBreak(message);

  if(!isEmpty(message)){

    pushMessage(message, true);
    input.innerHTML = "";
    resize();

  }

}
