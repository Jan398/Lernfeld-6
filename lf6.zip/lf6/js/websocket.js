var address;
var port = "4559";
var websocket;


function startWebSocket() {

  address = window.location.hostname;
  websocket = new WebSocket("ws://" + address + ":" + port);
  websocket.onopen = function() { websocket.onmessage = handleWebsocket; };

}



function handleWebsocket(message) {

  message = message.data;
  console.log(message);

}
